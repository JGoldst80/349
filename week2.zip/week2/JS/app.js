function hello() {
	alert("You're using " + navigator.appName);
}